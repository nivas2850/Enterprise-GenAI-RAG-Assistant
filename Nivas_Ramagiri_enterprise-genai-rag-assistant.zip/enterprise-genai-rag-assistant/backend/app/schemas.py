from pydantic import BaseModel
from typing import List, Optional

class AskRequest(BaseModel):
    question: str

class SourceChunk(BaseModel):
    source: str
    page: Optional[int] = None
    content: str

class AskResponse(BaseModel):
    answer: str
    sources: List[SourceChunk]
