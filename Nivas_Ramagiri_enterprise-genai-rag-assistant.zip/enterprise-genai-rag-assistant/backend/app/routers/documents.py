from fastapi import APIRouter, UploadFile, File, HTTPException
from app.config import UPLOAD_DIR
from app.services.pdf_service import load_pdf_as_documents
from app.services.rag_service import RAGService

router = APIRouter(prefix="/documents", tags=["Documents"])

@router.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    file_path = UPLOAD_DIR / file.filename
    with open(file_path, "wb") as f:
        f.write(await file.read())

    docs = load_pdf_as_documents(file_path)
    if not docs:
        raise HTTPException(status_code=400, detail="No readable text found in PDF.")

    rag = RAGService()
    chunks_created = rag.create_or_update_vectorstore(docs)

    return {
        "message": "Document uploaded and indexed successfully.",
        "file_name": file.filename,
        "pages_loaded": len(docs),
        "chunks_created": chunks_created,
    }
