from fastapi import APIRouter, HTTPException
from app.schemas import AskRequest, AskResponse, SourceChunk
from app.services.rag_service import RAGService

router = APIRouter(prefix="/chat", tags=["Chat"])

@router.post("/ask", response_model=AskResponse)
def ask_question(request: AskRequest):
    try:
        rag = RAGService()
        answer, docs = rag.ask(request.question)

        sources = [
            SourceChunk(
                source=doc.metadata.get("source", "unknown"),
                page=doc.metadata.get("page"),
                content=doc.page_content[:500],
            )
            for doc in docs
        ]

        return AskResponse(answer=answer, sources=sources)

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
