from typing import List, Tuple
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain.prompts import ChatPromptTemplate
from app.config import OPENAI_API_KEY, VECTORSTORE_PATH, MODEL_NAME, EMBEDDING_MODEL

class RAGService:
    def __init__(self):
        if not OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY is missing. Add it to backend/.env")

        self.embeddings = OpenAIEmbeddings(model=EMBEDDING_MODEL, api_key=OPENAI_API_KEY)
        self.llm = ChatOpenAI(model=MODEL_NAME, temperature=0.1, api_key=OPENAI_API_KEY)
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=900,
            chunk_overlap=150,
            separators=["\n\n", "\n", ".", " ", ""],
        )

    def create_or_update_vectorstore(self, docs: List[Document]) -> int:
        chunks = self.text_splitter.split_documents(docs)

        if VECTORSTORE_PATH.exists():
            vectorstore = FAISS.load_local(
                str(VECTORSTORE_PATH),
                self.embeddings,
                allow_dangerous_deserialization=True,
            )
            vectorstore.add_documents(chunks)
        else:
            vectorstore = FAISS.from_documents(chunks, self.embeddings)

        vectorstore.save_local(str(VECTORSTORE_PATH))
        return len(chunks)

    def ask(self, question: str) -> Tuple[str, List[Document]]:
        if not VECTORSTORE_PATH.exists():
            raise FileNotFoundError("Vector store not found. Upload documents first.")

        vectorstore = FAISS.load_local(
            str(VECTORSTORE_PATH),
            self.embeddings,
            allow_dangerous_deserialization=True,
        )

        retriever = vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 4})
        docs = retriever.invoke(question)

        context = "\n\n".join(
            [
                f"Source: {doc.metadata.get('source')} | Page: {doc.metadata.get('page')}\n{doc.page_content}"
                for doc in docs
            ]
        )

        prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    "You are an enterprise GenAI assistant. Answer only using the provided context. "
                    "If the answer is not present in the context, say you do not have enough information. "
                    "Include document names and page references when useful.",
                ),
                ("human", "Question: {question}\n\nContext:\n{context}"),
            ]
        )

        chain = prompt | self.llm
        response = chain.invoke({"question": question, "context": context})
        return response.content, docs
