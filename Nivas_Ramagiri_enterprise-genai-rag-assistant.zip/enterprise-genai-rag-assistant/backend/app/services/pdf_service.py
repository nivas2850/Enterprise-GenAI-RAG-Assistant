from pathlib import Path
from typing import List
from pypdf import PdfReader
from langchain.schema import Document

def load_pdf_as_documents(file_path: Path) -> List[Document]:
    reader = PdfReader(str(file_path))
    docs = []

    for page_number, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        text = text.strip()
        if text:
            docs.append(
                Document(
                    page_content=text,
                    metadata={"source": file_path.name, "page": page_number},
                )
            )
    return docs
