from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import documents, chat

app = FastAPI(
    title="Enterprise GenAI RAG Assistant",
    description="Upload PDFs and ask context-grounded questions using RAG, LangChain, OpenAI, and FAISS.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(documents.router)
app.include_router(chat.router)

@app.get("/")
def root():
    return {"message": "Enterprise GenAI RAG Assistant API is running.", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "healthy"}
