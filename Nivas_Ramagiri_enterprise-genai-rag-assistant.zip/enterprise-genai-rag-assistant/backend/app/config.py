import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parents[1]
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
VECTORSTORE_PATH = BASE_DIR / os.getenv("VECTORSTORE_PATH", "vectorstore/faiss_index")
UPLOAD_DIR = BASE_DIR / os.getenv("UPLOAD_DIR", "uploads")
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-4o-mini")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
VECTORSTORE_PATH.parent.mkdir(parents=True, exist_ok=True)
