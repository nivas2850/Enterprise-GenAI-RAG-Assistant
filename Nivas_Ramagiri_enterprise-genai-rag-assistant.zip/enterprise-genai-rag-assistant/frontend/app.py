import streamlit as st
import requests

API_URL = "http://localhost:8000"

st.set_page_config(page_title="Enterprise GenAI RAG Assistant", page_icon="🤖", layout="wide")

st.title("🤖 Enterprise GenAI RAG Assistant")
st.write("Upload enterprise PDFs, policies, contracts, or reports and ask context-grounded questions.")

with st.sidebar:
    st.header("📄 Upload Document")
    uploaded_file = st.file_uploader("Upload a PDF", type=["pdf"])

    if uploaded_file and st.button("Upload and Index"):
        with st.spinner("Uploading and indexing document..."):
            files = {"file": (uploaded_file.name, uploaded_file.getvalue(), "application/pdf")}
            response = requests.post(f"{API_URL}/documents/upload", files=files)
            if response.status_code == 200:
                st.success("Document indexed successfully!")
                st.json(response.json())
            else:
                st.error(response.text)

st.header("💬 Ask a Question")
question = st.text_input("Enter your question")

if st.button("Ask AI"):
    if not question.strip():
        st.warning("Please enter a question.")
    else:
        with st.spinner("Generating grounded answer..."):
            response = requests.post(f"{API_URL}/chat/ask", json={"question": question})
            if response.status_code == 200:
                data = response.json()
                st.subheader("✅ Answer")
                st.write(data["answer"])
                st.subheader("📌 Source Citations")
                for idx, source in enumerate(data["sources"], start=1):
                    with st.expander(f"Source {idx}: {source['source']} | Page {source.get('page')}"):
                        st.write(source["content"])
            else:
                st.error(response.text)
