# Enterprise GenAI RAG Assistant

Enterprise GenAI RAG Assistant is a production-style Retrieval-Augmented Generation application that allows users to upload PDF documents and ask context-aware questions. The system retrieves the most relevant document chunks using semantic search and generates grounded answers using an LLM.

This project demonstrates modern GenAI engineering skills including RAG, embeddings, vector search, prompt engineering, LLM orchestration, FastAPI backend development, and Streamlit UI development.

---

## 🚀 Features

- PDF document upload
- Automatic PDF text extraction
- Document chunking with overlap
- Embedding generation using OpenAI embeddings
- Vector search using FAISS
- Context-grounded question answering
- Source citations with document name and page number
- Hallucination reduction through context-only prompting
- FastAPI backend
- Streamlit frontend
- Docker Compose setup

---

## 🧠 Tech Stack

**Backend:** Python, FastAPI  
**Frontend:** Streamlit  
**GenAI / LLM:** OpenAI API, LangChain  
**Vector Database:** FAISS  
**Document Processing:** PyPDF  
**Deployment:** Docker, Docker Compose  

---

## 🏗️ Architecture Diagram

![Architecture Diagram](./screenshots/architecture-diagram.png)

---

## 🔥 RAG Workflow

![RAG Workflow](./screenshots/rag-workflow.png)

---

## 🧩 Application Screens

![Application Screens](./screenshots/application-screens.png)

---

## 🔄 System Flow

```text
User uploads PDF
        ↓
FastAPI receives file
        ↓
PDF text extraction
        ↓
Text chunking
        ↓
OpenAI embeddings
        ↓
FAISS vector storage
        ↓
User asks question
        ↓
Semantic search retrieves relevant chunks
        ↓
LLM generates grounded answer
        ↓
Answer returned with source citations
```

---

## 📁 Project Structure

```text
enterprise-genai-rag-assistant/
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── config.py
│   │   ├── schemas.py
│   │   ├── routers/
│   │   │   ├── documents.py
│   │   │   └── chat.py
│   │   └── services/
│   │       ├── pdf_service.py
│   │       └── rag_service.py
│   ├── uploads/
│   ├── vectorstore/
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── app.py
│   └── requirements.txt
├── screenshots/
├── sample_docs/
├── docker-compose.yml
└── README.md
```

---

## ⚙️ Environment Variables

Create:

```text
backend/.env
```

Add:

```env
OPENAI_API_KEY=your_openai_api_key_here
VECTORSTORE_PATH=vectorstore/faiss_index
UPLOAD_DIR=uploads
MODEL_NAME=gpt-4o-mini
EMBEDDING_MODEL=text-embedding-3-small
```

---

## ▶️ Run Locally Without Docker

### Backend

```bash
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open:

```text
http://localhost:8000/docs
```

### Frontend

```bash
cd frontend
pip install -r requirements.txt
streamlit run app.py
```

Open:

```text
http://localhost:8501
```

---

## 🐳 Run With Docker

Create `backend/.env`, then run:

```bash
docker-compose up --build
```

FastAPI:

```text
http://localhost:8000/docs
```

Streamlit:

```text
http://localhost:8501
```

---

## 📌 API Endpoints

### Upload PDF

```http
POST /documents/upload
```

### Ask Question

```http
POST /chat/ask
```

Request:

```json
{
  "question": "What are the key compliance requirements in this policy?"
}
```

Response:

```json
{
  "answer": "The policy requires...",
  "sources": [
    {
      "source": "policy.pdf",
      "page": 2,
      "content": "Relevant source text..."
    }
  ]
}
```

---

## 🧠 Hallucination Reduction Strategy

The assistant is instructed to answer only from retrieved document context. If the answer is not present in the uploaded documents, the model responds that it does not have enough information. This improves groundedness and reduces hallucinations.

---

## 🌐 Portfolio Description

Built an Enterprise GenAI RAG Assistant that enables users to upload PDFs and ask document-grounded questions using LLMs. Implemented PDF parsing, semantic chunking, OpenAI embeddings, FAISS vector search, LangChain orchestration, FastAPI backend APIs, Streamlit UI, and source citations to reduce hallucinations and improve answer reliability.

---

## 💼 Resume Bullets

- Built an enterprise-grade GenAI RAG assistant using Python, LangChain, OpenAI, FAISS, FastAPI, and Streamlit to answer user questions from uploaded PDFs with source citations.
- Implemented PDF parsing, text chunking, embedding generation, and semantic retrieval workflows to provide context-grounded LLM responses and reduce hallucinations.
- Designed FastAPI endpoints for document upload and AI-powered question answering, enabling scalable backend integration for enterprise knowledge search.
- Developed a Streamlit interface for PDF upload, real-time question answering, and source citation display, improving usability for document-based AI workflows.

---

## 🔮 Future Improvements

- Add Milvus or Pinecone support
- Add authentication
- Add chat history
- Add multi-document filtering
- Add evaluation metrics for groundedness and relevance
- Deploy backend on AWS ECS and frontend on Streamlit Cloud

---

## Author

Nivas Ramagiri
